# SORT TEST

Copyright (C) 2019 Wang Huaqiang

---

## Usage:

```
gcc test.c -o test
```

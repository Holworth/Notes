#ifndef INCLUDE_TASK4_H_
#define INCLUDE_TASK4_H_

#include "type.h"

//test drawing
void lab4_drawing_task1(void);

//test memory
void rw_task1(void);

//additional test
void pressure_test(void);
void pressure_test2(void);
void mem_swap_test(void);

#endif

#ifndef INCLUDE_TASK2_H_
#define INCLUDE_TASK2_H_

#include "type.h"

// task1 test task
void printk_task1(void);
void printk_task2(void);
void drawing_task1(void);

// task2 test task
void lock_task1(void);
void lock_task2(void);
void lock_task3(void);
void lock_task4(void);
void lock_task5(void);

// task3 test task
void printf_task1(void);
void printf_task2(void);
void drawing_task2(void);

// task4 test task
void sleep_task(void);
void timer_task(void);

#endif

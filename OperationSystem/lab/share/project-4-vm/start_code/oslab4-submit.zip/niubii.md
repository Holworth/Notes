    ehi=ehi<<13;
    ehi=ehi>>13;
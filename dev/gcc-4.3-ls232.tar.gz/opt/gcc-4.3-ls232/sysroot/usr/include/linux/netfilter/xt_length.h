#ifndef _XT_LENGTH_H
#define _XT_LENGTH_H

struct xt_length_info {
    u_int16_t	min, max;
    u_int8_t	invert;
};

#endif /*_XT_LENGTH_H*/

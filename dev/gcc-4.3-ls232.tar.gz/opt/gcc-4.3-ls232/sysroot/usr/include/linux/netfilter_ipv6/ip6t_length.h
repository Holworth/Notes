#ifndef _IP6T_LENGTH_H
#define _IP6T_LENGTH_H

#include <linux/netfilter/xt_length.h>
#define ip6t_length_info xt_length_info

#endif /*_IP6T_LENGTH_H*/
	

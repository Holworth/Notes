#ifndef __LINUX_KVM_MIPS_H
#define __LINUX_KVM_MIPS_H

/* mips does not support KVM */

#endif
